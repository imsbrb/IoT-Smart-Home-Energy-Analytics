-- 1. Create the database
CREATE DATABASE iot_energy_dw;

DROP SCHEMA IF EXISTS dw CASCADE;
CREATE SCHEMA dw;
SET search_path TO dw;
--------- staging table ----------

create table staging_energy (
    date timestamp,
    appliances float,
    lights float,
    t1 float, rh_1 float,
    t2 float, rh_2 float,
    t3 float, rh_3 float,
    t4 float, rh_4 float,
    t5 float, rh_5 float,
    t6 float, rh_6 float,
    t7 float, rh_7 float,
    t8 float, rh_8 float,
    t9 float, rh_9 float,
    T_out float,
    pressure float,
    rh_out float,
    windspeed float,
    visibility float,
    dewpoint float,
    rv1 float,
    rv2 float
);


------ dimension tables --------------

-- =========================
-- DIMENSION: DATE
-- date_key is a surrogate key (auto-generated)
-- instead of using the date directly, which simplifies joins and indexing.
-- This allows multiple entries for the same date if necessary (e.g., multiple years, calendars).
-- =========================

create table dw.dim_date (
    date_key serial primary key,
    full_date date,
    day int,
    month int,
    year int,
    weekday varchar(10),
    is_weekend boolean
);

-- =========================
-- DIMENSION: TIME
-- time_key is a surrogate key uniquely identifying each time entry (hour, minute).
-- It allows for efficient joins between facts and specific times of day,
-- while supporting attributes like "part_of_day" (morning, afternoon, etc.).
-- =========================

create table dw.dim_time (
    time_key serial primary key,
    hour int,
    minute int,
    part_of_day varchar(20)
);

-- =========================
-- DIMENSION: ROOM
-- room_key is a surrogate key representing each room or area being monitored.
-- Using a numeric key instead of room_name speeds up joins and allows renaming of rooms without affecting relationships.
-- =========================

create table dw.dim_room (
    room_key serial primary key,
    room_name varchar(50)
);

-- =========================
-- DIMENSION: WEATHER
-- weather_key is a surrogate key representing a distinct weather record.
-- This makes it easy to reference environmental conditions without duplicating values in the fact table.
-- =========================

create table dw.dim_weather (
    weather_key serial primary key,
    outdoor_temp float,
    outdoor_humidity float,
    pressure float,
    windspeed float,
    visibility float,
    dewpoint float
);


---------- fact tables -----------------

-- =========================
-- FACT TABLE (ETL version)
-- fact_id is a surrogate primary key uniquely identifying each energy usage record.
-- It links to all dimensions using their surrogate keys (date_key, time_key, room_key, weather_key).
-- This structure supports a star schema for efficient OLAP queries.
-- =========================

create table dw.fact_energyusage_etl (
    fact_id serial primary key,
    date_key int references dw.dim_date(date_key),
    time_key int references dw.dim_time(time_key),
    room_key int references dw.dim_room(room_key),
    weather_key int references dw.dim_weather(weather_key),
    appliances_wh float,
    lights_wh float,
    avg_temp float,
    avg_humidity float
);

-- =========================
-- FACT TABLE (ELT version)
-- fact_id serves as the unique identifier for each raw record.
-- This denormalized version retains all sensor readings directly,
-- so it does not use foreign keys to dimensions.
-- =========================

create table dw.fact_energyusage_elt (
    fact_id serial primary key,
    date timestamp,
    appliances float,
    lights float,
    t1 float, rh_1 float,
    t2 float, rh_2 float,
    t3 float, rh_3 float,
    t4 float, rh_4 float,
    t5 float, rh_5 float,
    t6 float, rh_6 float,
    t7 float, rh_7 float,
    t8 float, rh_8 float,
    t9 float, rh_9 float,
    T_out float,
    pressure float,
    rh_out float,
    windspeed float,
    visibility float,
    dewpoint float,
    avg_temp float,
    avg_humidity float
);

Select * from dw.staging_energy;