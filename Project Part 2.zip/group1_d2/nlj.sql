-- Force Nested Loop Join
SET enable_hashjoin = off;
SET enable_mergejoin = off;
SET enable_nestloop = on;

EXPLAIN ANALYZE
SELECT 
    d.year, d.month, 
    AVG(f.appliances_wh) AS avg_app_usage,
    AVG(f.lights_wh) AS avg_light_usage
FROM dw.fact_energyusage_etl f
JOIN dw.dim_date d ON f.date_key = d.date_key
WHERE d.year = 2023
GROUP BY d.year, d.month
ORDER BY d.year, d.month;


-- Force Sort-Merge Join
SET enable_hashjoin = off;
SET enable_mergejoin = on;
SET enable_nestloop = off;

EXPLAIN ANALYZE
SELECT 
    d.year, d.month, 
    AVG(f.appliances_wh) AS avg_app_usage,
    AVG(f.lights_wh) AS avg_light_usage
FROM dw.fact_energyusage_etl f
JOIN dw.dim_date d ON f.date_key = d.date_key
WHERE d.year = 2023
GROUP BY d.year, d.month
ORDER BY d.year, d.month;


-- Force Hash Join
SET enable_hashjoin = on;
SET enable_mergejoin = off;
SET enable_nestloop = off;

EXPLAIN ANALYZE
SELECT 
    d.year, d.month, 
    AVG(f.appliances_wh) AS avg_app_usage,
    AVG(f.lights_wh) AS avg_light_usage
FROM dw.fact_energyusage_etl f
JOIN dw.dim_date d ON f.date_key = d.date_key
WHERE d.year = 2023
GROUP BY d.year, d.month
ORDER BY d.year, d.month;


-- DSS Query: Monthly average energy usage
EXPLAIN ANALYZE
SELECT 
    d.year, d.month,
    ROUND(AVG(f.appliances_wh + f.lights_wh), 2) AS avg_energy_wh
FROM dw.fact_energyusage_etl f
JOIN dw.dim_date d ON f.date_key = d.date_key
GROUP BY d.year, d.month
ORDER BY d.year, d.month;