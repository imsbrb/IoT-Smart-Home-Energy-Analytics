-- OLAP Analytical Queries on IoT Energy Data
-- 1. Monthly average appliance and light energy usage
SELECT 
    d.year,
    d.month,
    ROUND(AVG(f.appliances_wh), 2) AS avg_appliance_usage,
    ROUND(AVG(f.lights_wh), 2) AS avg_light_usage
FROM dw.fact_energyusage_etl f
JOIN dw.dim_date d ON f.date_key = d.date_key
GROUP BY d.year, d.month
ORDER BY d.year, d.month;

-- 2. Daily total energy consumption (Appliances + Lights)
SELECT 
    d.full_date,
    SUM(f.appliances_wh + f.lights_wh) AS total_energy_wh
FROM dw.fact_energyusage_etl f
JOIN dw.dim_date d ON f.date_key = d.date_key
GROUP BY d.full_date
ORDER BY d.full_date;

-- 3. Average room temperature and humidity by part of day
SELECT 
    t.part_of_day,
    ROUND(AVG(f.avg_temp), 2) AS avg_temp,
    ROUND(AVG(f.avg_humidity), 2) AS avg_humidity
FROM dw.fact_energyusage_etl f
JOIN dw.dim_time t ON f.time_key = t.time_key
GROUP BY t.part_of_day
ORDER BY t.part_of_day;

-- 4. Energy usage by room
SELECT 
    r.room_name,
    ROUND(SUM(f.appliances_wh + f.lights_wh), 2) AS total_energy_wh
FROM dw.fact_energyusage_etl f
JOIN dw.dim_room r ON f.room_key = r.room_key
GROUP BY r.room_name
ORDER BY total_energy_wh DESC;

-- 5. Correlation between outdoor temperature and appliance energy usage
SELECT 
    ROUND(CORR(f.appliances_wh, w.outdoor_temp)::numeric, 3) AS corr_appliances_temp
FROM dw.fact_energyusage_etl f
JOIN dw.dim_weather w ON f.weather_key = w.weather_key;