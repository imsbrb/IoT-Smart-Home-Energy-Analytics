-- MOLAP Summary Tables for Precomputed Aggregations


-- 1. Monthly summary table
DROP TABLE IF EXISTS dw.molap_monthly_summary CASCADE;
CREATE TABLE dw.molap_monthly_summary AS
SELECT 
    d.year,
    d.month,
    ROUND(AVG(f.appliances_wh), 2) AS avg_appliance_usage,
    ROUND(AVG(f.lights_wh), 2) AS avg_light_usage,
    ROUND(AVG(f.avg_temp), 2) AS avg_temp,
    ROUND(AVG(f.avg_humidity), 2) AS avg_humidity
FROM dw.fact_energyusage_etl f
JOIN dw.dim_date d ON f.date_key = d.date_key
GROUP BY d.year, d.month;

-- 2. Create index for faster lookups
CREATE INDEX idx_molap_monthly_summary ON dw.molap_monthly_summary(year, month);

-- 3. Verify correctness by comparing MOLAP vs OLAP results
-- (Example validation query)
SELECT 
    olap.year, 
    olap.month,
    olap.avg_appliance_usage AS olap_value,
    molap.avg_appliance_usage AS molap_value,
    (olap.avg_appliance_usage - molap.avg_appliance_usage) AS diff
FROM (
    SELECT 
        d.year, d.month,
        ROUND(AVG(f.appliances_wh), 2) AS avg_appliance_usage
    FROM dw.fact_energyusage_etl f
    JOIN dw.dim_date d ON f.date_key = d.date_key
    GROUP BY d.year, d.month
) olap
JOIN dw.molap_monthly_summary molap
  ON olap.year = molap.year AND olap.month = molap.month;