set search_path to dw;

-- btree index tests
explain analyze
select sum(appliances_wh)
from fact_energyusage_etl f
join dim_date d on f.date_key = d.date_key
where d.year = 2016 and d.month between 1 and 3;

create index if not exists idx_btree_datekey
on fact_energyusage_etl(date_key);

explain analyze
select sum(appliances_wh)
from fact_energyusage_etl f
join dim_date d on f.date_key = d.date_key
where d.year = 2016 and d.month between 1 and 3;



-- bitmap simulation (hash + btree)
explain analyze
select *
from fact_energyusage_elt
where windspeed = 5 and visibility = 2;

create index if not exists idx_hash_windspeed
on fact_energyusage_elt using hash(windspeed);

create index if not exists idx_btree_visibility
on fact_energyusage_elt(visibility);

explain analyze
select *
from fact_energyusage_elt
where windspeed = 5 and visibility = 2;

-- vp setup
-- create core table

create table fact_energy_core (
    fact_id serial primary key,
    date_key int,
    appliances_wh float,
    lights_wh float,
    avg_temp float,
    avg_humidity float
);

create table fact_energy_sensors (
    fact_id int primary key references fact_energy_core(fact_id),
    t1 float, rh_1 float,
    t2 float, rh_2 float,
    t3 float, rh_3 float,
    t4 float, rh_4 float,
    t5 float, rh_5 float,
    t6 float, rh_6 float,
    t7 float, rh_7 float,
    t8 float, rh_8 float,
    t9 float, rh_9 float,
    t_out float,
    pressure float,
    rh_out float,
    windspeed float,
    visibility float,
    dewpoint float
);

--populate
WITH core_insert AS (
    INSERT INTO fact_energy_core (date_key, appliances_wh, lights_wh, avg_temp, avg_humidity)
    SELECT date_key, appliances_wh, lights_wh, avg_temp, avg_humidity
    FROM fact_energyusage_etl
    RETURNING fact_id, date_key
)
INSERT INTO fact_energy_sensors (
    fact_id,
    t1, rh_1, t2, rh_2, t3, rh_3, t4, rh_4,
    t5, rh_5, t6, rh_6, t7, rh_7, t8, rh_8, t9, rh_9,
    t_out, pressure, rh_out, windspeed, visibility, dewpoint
)
SELECT
    c.fact_id,
    elt.t1, elt.rh_1, elt.t2, elt.rh_2, elt.t3, elt.rh_3, elt.t4, elt.rh_4,
    elt.t5, elt.rh_5, elt.t6, elt.rh_6, elt.t7, elt.rh_7, elt.t8, elt.rh_8, elt.t9, elt.rh_9,
    elt.t_out, elt.pressure, elt.rh_out, elt.windspeed, elt.visibility, elt.dewpoint
FROM core_insert c
JOIN dim_date d
    ON d.date_key = c.date_key
JOIN fact_energyusage_elt elt
    ON elt.date = d.full_date; 

-- before vp baseline test
explain analyze
select date_key, appliances_wh, avg_temp
from fact_energyusage_etl
where date_key between 1000 and 2000;

-- after vp 
explain analyze
select date_key, appliances_wh, avg_temp
from fact_energy_core
where date_key between 1000 and 2000;


-- sensor + core
explain analyze
select *
from fact_energy_core c
join fact_energy_sensors s
    on c.fact_id = s.fact_id
where c.date_key between 1000 and 2000;

-- mv setup
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_monthly_energy AS
SELECT
    d.year,
    d.month,
    SUM(c.appliances_wh)   AS total_appliances,
    SUM(c.lights_wh)       AS total_lights,
    AVG(c.avg_temp)        AS avg_temp,
    AVG(c.avg_humidity)    AS avg_humidity
FROM fact_energy_core c
JOIN dim_date d
    ON c.date_key = d.date_key
GROUP BY d.year, d.month
WITH DATA;


create index if not exists idx_mv_year_month on mv_monthly_energy(year, month);

-- before mv 
explain analyze
select d.year, d.month, sum(c.appliances_wh)
from fact_energy_core c
join dim_date d on c.date_key = d.date_key
where d.year = 2016
group by d.year, d.month;


-- mv test (fast lookup)
explain analyze
select *
from mv_monthly_energy
where year = 2016;

