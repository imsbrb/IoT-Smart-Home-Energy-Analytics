set search_path to dw;


------------ STEP 1: CLEAN STAGING ----------------

delete from staging_energy
where date is null or appliances is null or lights is null;

delete from staging_energy a
using staging_energy b
where a.ctid < b.ctid
and a.date = b.date;


---------- STEP 2: REBUILD DIMENSIONS -------
truncate table dim_date restart identity cascade;
truncate table dim_time restart identity cascade;

truncate table dim_room restart identity cascade;
truncate table dim_weather restart identity cascade;

-- Date dimension
insert into dim_date (full_date, day, month, year, weekday, is_weekend)
select distinct
    date(date),
    extract(day from date),
    extract(month from date),
    extract(year from date),
    trim(to_char(date, 'Day')),
    case when extract(isodow from date) in (6,7) then true else false end
from staging_energy;


-- Time dimension
insert into dim_time (hour, minute, part_of_day)
select distinct
    extract(hour from date),
    extract(minute from date),
    case
        when extract(hour from date) between 5 and 11 then 'morning'
        when extract(hour from date) between 12 and 16 then 'afternoon'
        when extract(hour from date) between 17 and 20 then 'evening'
        else 'night'
    end
from staging_energy;


-- Room dimension (static)
insert into dim_room (room_name)
values ('all rooms')
on conflict (room_name) do nothing;


-- Weather dimension (unique)
insert into dim_weather (outdoor_temp, outdoor_humidity, pressure, windspeed, visibility, dewpoint)
select distinct
    round(t_out::numeric, 2),
    round(rh_out::numeric, 2),
    round(pressure::numeric, 2),
    round(windspeed::numeric, 2),
    round(visibility::numeric, 2),
    round(dewpoint::numeric, 2)
from staging_energy;


---------- STEP 3: LOAD FACT TABLE -----------

truncate table fact_energyusage_etl restart identity;

insert into fact_energyusage_etl (
    date_key, time_key, room_key, weather_key,
    appliances_wh, lights_wh, avg_temp, avg_humidity
)
select
    d.date_key,
    t.time_key,
    r.room_key,
    w.weather_key,
    s.appliances,
    s.lights,
    (s.t1 + s.t2 + s.t3 + s.t4 + s.t5 + s.t6 + s.t7 + s.t8 + s.t9) / 9 as avg_temp,
    (s.rh_1 + s.rh_2 + s.rh_3 + s.rh_4 + s.rh_5 + s.rh_6 + s.rh_7 + s.rh_8 + s.rh_9) / 9 as avg_humidity
from staging_energy s
join dim_date d 
  on d.full_date = date(s.date)
join dim_time t 
  on t.hour = extract(hour from s.date)
 and t.minute = extract(minute from s.date)
join dim_room r 
  on r.room_name = 'all rooms'
left join dim_weather w
  on round(w.outdoor_temp::numeric, 2) = round(s.t_out::numeric, 2)
 and round(w.outdoor_humidity::numeric, 2) = round(s.rh_out::numeric, 2)
 and round(w.pressure::numeric, 2) = round(s.pressure::numeric, 2)
 and round(w.windspeed::numeric, 2) = round(s.windspeed::numeric, 2)
 and round(w.visibility::numeric, 2) = round(s.visibility::numeric, 2)
 and round(w.dewpoint::numeric, 2) = round(s.dewpoint::numeric, 2);



 select 
    (select count(*) from staging_energy) as staging_count,
    (select count(*) from fact_energyusage_etl) as etl_count,
    (select count(*) from fact_energyusage_elt) as elt_count;

