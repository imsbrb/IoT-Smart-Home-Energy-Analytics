
create database iot_energy_dw;


create schema dw;
set search_path to dw;



--------- staging table ----------

create table staging_energy (
    date timestamp,
    appliances float,
    lights float,
    t1 float, rh_1 float,
    t2 float, rh_2 float,
    t3 float, rh_3 float,
    t4 float, rh_4 float,
    t5 float, rh_5 float,
    t6 float, rh_6 float,
    t7 float, rh_7 float,
    t8 float, rh_8 float,
    t9 float, rh_9 float,
    T_out float,
    pressure float,
    rh_out float,
    windspeed float,
    visibility float,
    dewpoint float,
    rv1 float,
    rv2 float
);


------ dimension tables --------------


create table dw.dim_date (
    date_key serial primary key,
    full_date date,
    day int,
    month int,
    year int,
    weekday varchar(10),
    is_weekend boolean
);

create table dw.dim_time (
    time_key serial primary key,
    hour int,
    minute int,
    part_of_day varchar(20)
);

create table dw.dim_room (
    room_key serial primary key,
    room_name varchar(50)
);

create table dw.dim_weather (
    weather_key serial primary key,
    outdoor_temp float,
    outdoor_humidity float,
    pressure float,
    windspeed float,
    visibility float,
    dewpoint float
);


---------- fact tables -----------------


create table dw.fact_energyusage_etl (
    fact_id serial primary key,
    date_key int references dw.dim_date(date_key),
    time_key int references dw.dim_time(time_key),
    room_key int references dw.dim_room(room_key),
    weather_key int references dw.dim_weather(weather_key),
    appliances_wh float,
    lights_wh float,
    avg_temp float,
    avg_humidity float
);


create table dw.fact_energyusage_elt (
    fact_id serial primary key,
    date timestamp,
    appliances float,
    lights float,
    t1 float, rh_1 float,
    t2 float, rh_2 float,
    t3 float, rh_3 float,
    t4 float, rh_4 float,
    t5 float, rh_5 float,
    t6 float, rh_6 float,
    t7 float, rh_7 float,
    t8 float, rh_8 float,
    t9 float, rh_9 float,
    T_out float,
    pressure float,
    rh_out float,
    windspeed float,
    visibility float,
    dewpoint float,
    avg_temp float,
    avg_humidity float
);

Select * from dw.staging_energy;
