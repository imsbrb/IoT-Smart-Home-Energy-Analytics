
set search_path to dw;

------------ STEP 1: LOAD RAW DATA INTO ELT FACT TABLE-------------------------

truncate table fact_energyusage_elt;

-- load all columns from staging into the ELT fact table
insert into fact_energyusage_elt (
    date, appliances, lights,
    t1, rh_1, t2, rh_2, t3, rh_3,
    t4, rh_4, t5, rh_5, t6, rh_6,
    t7, rh_7, t8, rh_8, t9, rh_9,
    t_out, pressure, rh_out, windspeed, visibility, dewpoint
)
select
    date, appliances, lights,
    t1, rh_1, t2, rh_2, t3, rh_3,
    t4, rh_4, t5, rh_5, t6, rh_6,
    t7, rh_7, t8, rh_8, t9, rh_9,
    t_out, pressure, rh_out, windspeed, visibility, dewpoint
from staging_energy;


----------- STEP 2: TRANSFORM INSIDE THE DATABASE (ELT) -------------


alter table fact_energyusage_elt
    add column if not exists avg_temp float,
    add column if not exists avg_humidity float;

-- calculate average temperature across 9 sensors
update fact_energyusage_elt
set avg_temp = (t1 + t2 + t3 + t4 + t5 + t6 + t7 + t8 + t9) / 9;

-- calculate average humidity across 9 sensors
update fact_energyusage_elt
set avg_humidity = (rh_1 + rh_2 + rh_3 + rh_4 + rh_5 + rh_6 + rh_7 + rh_8 + rh_9) / 9;


------------ STEP 3: VERIFY RESULTS AND COMPARE WITH ETL OUTPUT -----------------

select count(*) as total_rows_elt from fact_energyusage_elt;

-- total energy usage for verification
select sum(appliances) as total_appliances_elt from fact_energyusage_elt;


select
    (select count(*) from fact_energyusage_etl) as etl_count,
    (select count(*) from fact_energyusage_elt) as elt_count,
    (select sum(appliances_wh) from fact_energyusage_etl) as etl_total,
    (select sum(appliances) from fact_energyusage_elt) as elt_total;


select date, appliances, lights, avg_temp, avg_humidity
from fact_energyusage_elt
limit 10;
